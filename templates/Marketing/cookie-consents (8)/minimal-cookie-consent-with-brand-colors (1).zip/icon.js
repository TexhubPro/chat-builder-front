"use client";

import {Icon as BaseIcon} from "@iconify/react";

export const Icon = (props) => {
  return <BaseIcon {...props} />;
};
